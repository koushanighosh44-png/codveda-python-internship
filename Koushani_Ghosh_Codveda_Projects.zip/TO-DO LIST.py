# 1 TASK PROJECT(CODVEDA TECHNOLOGIES) -- TO - DO LIST



import json
import os

FILE_NAME = "todo_list.json"

def load_tasks():
    """Load tasks from the JSON file."""
    if os.path.exists(FILE_NAME):
        with open(FILE_NAME, 'r') as file:
            try:
                return json.load(file)
            except json.JSONDecodeError:
                return []
    return []

def save_tasks(tasks):
    """Save the list of tasks to the JSON file."""
    with open(FILE_NAME, 'w') as file:
        json.dump(tasks, file, indent=4)

def add_task(tasks):
    """Add a new task to the list."""
    task_title = input("Enter the task: ").strip()
    if task_title:
        new_task = {"title": task_title, "completed": False}
        tasks.append(new_task)
        save_tasks(tasks)
        print(f"Task '{task_title}' added successfully!")
    else:
        print("Task cannot be empty.")

def view_tasks(tasks):
    """Display all tasks with their status."""
    if not tasks:
        print("No tasks in the list.")
        return
    
    print("\nYour To-Do List:")
    for idx, task in enumerate(tasks, 1):
        status = "✓" if task["completed"] else " "
        print(f"{idx}. [{status}] {task['title']}")
    print()

def mark_task_complete(tasks):
    """Mark a task as completed."""
    view_tasks(tasks)
    try:
        task_num = int(input("Enter the task number to mark as complete: "))
        if 1 <= task_num <= len(tasks):
            tasks[task_num - 1]["completed"] = True
            save_tasks(tasks)
            print(f"Task {task_num} marked as complete!")
        else:
            print("Invalid task number.")
    except ValueError:
        print("Please enter a valid number.")

def delete_task(tasks):
    """Delete a task from the list."""
    view_tasks(tasks)
    try:
        task_num = int(input("Enter the task number to delete: "))
        if 1 <= task_num <= len(tasks):
            removed_task = tasks.pop(task_num - 1)
            save_tasks(tasks)
            print(f"Task '{removed_task['title']}' deleted!")
        else:
            print("Invalid task number.")
    except ValueError:
        print("Please enter a valid number.")

def main():
    """Main function to run the To-Do List application."""
    tasks = load_tasks()
    
    while True:
        print("\n--- To-Do List Menu ---")
        print("1. Add Task")
        print("2. View Tasks")
        print("3. Mark Task as Complete")
        print("4. Delete Task")
        print("5. Exit")
        
        choice = input("Choose an option (1-5): ").strip()
        
        if choice == '1':
            add_task(tasks)
        elif choice == '2':
            view_tasks(tasks)
        elif choice == '3':
            mark_task_complete(tasks)
        elif choice == '4':
            delete_task(tasks)
        elif choice == '5':
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()