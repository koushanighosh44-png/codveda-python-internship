

#3 TASK PROJECT(CODVEDA TECHNOLOGIES) --API INTEGRATION


import requests
import json
from datetime import datetime

class WeatherApp:
    def __init__(self):
        self.api_key = "1da7afb851bae313755b5177ed3e8450"  # Your actual API key
        self.base_url = "http://api.openweathermap.org/data/2.5/weather"
    
    def get_weather(self, city_name):
        """
        Fetch weather data for a given city
        """
        try:
            # API parameters
            params = {
                'q': city_name,
                'appid': self.api_key,
                'units': 'metric',  # Celsius temperature
                'lang': 'en'
            }
            
            print(f"Fetching weather data for {city_name}...")
            
            # API request
            response = requests.get(self.base_url, params=params, timeout=10)
            
            if response.status_code == 200:
                weather_data = response.json()
                self.display_weather(weather_data)
                self.save_to_file(city_name, weather_data)
                return True
            elif response.status_code == 401:
                print("Invalid API Key! Please check your API key.")
                return False
            elif response.status_code == 404:
                print(f" City '{city_name}' not found! Please check spelling.")
                return False
            else:
                print(f" API Error: Status code {response.status_code}")
                return False
                
        except requests.exceptions.ConnectionError:
            print(" Network Error: Please check your internet connection!")
            return False
        except requests.exceptions.Timeout:
            print("Request Timeout: Please try again!")
            return False
        except Exception as e:
            print(f" Unexpected error: {e}")
            return False
    
    def display_weather(self, weather_data):
        """
        Display weather information in user-friendly format
        """
        try:
            # Extract data from API response
            city = weather_data['name']
            country = weather_data['sys']['country']
            temperature = weather_data['main']['temp']
            feels_like = weather_data['main']['feels_like']
            humidity = weather_data['main']['humidity']
            pressure = weather_data['main']['pressure']
            weather_desc = weather_data['weather'][0]['description']
            wind_speed = weather_data['wind']['speed']
            
            # Convert timestamp to readable time
            sunrise = datetime.fromtimestamp(weather_data['sys']['sunrise']).strftime('%H:%M:%S')
            sunset = datetime.fromtimestamp(weather_data['sys']['sunset']).strftime('%H:%M:%S')
            
            # Display weather information
            print("\n" + "="*50)
            print(f"  WEATHER REPORT - {city}, {country}")
            print("="*50)
            print(f" Description: {weather_desc.title()}")
            print(f"  Temperature: {temperature}°C")
            print(f" Feels like: {feels_like}°C")
            print(f" Humidity: {humidity}%")
            print(f" Pressure: {pressure} hPa")
            print(f" Wind Speed: {wind_speed} m/s")
            print(f" Sunrise: {sunrise}")
            print(f" Sunset: {sunset}")
            print("="*50)
            
            # Additional recommendations based on weather
            self.weather_recommendations(weather_desc, temperature)
            
        except KeyError as e:
            print(f" Error parsing weather data: Missing {e}")
    
    def weather_recommendations(self, description, temperature):
        """
        Provide recommendations based on weather conditions
        """
        print("\n Recommendations:")
        
        if "rain" in description.lower():
            print("   • Carry an umbrella ")
            print("   • Wear waterproof shoes")
            print("   • Avoid outdoor activities")
        elif "thunderstorm" in description.lower():
            print("   • Stay indoors ")
            print("   • Unplug electronic devices")
            print("   • Avoid using wired electronics")
        elif temperature > 35:
            print("   • Stay hydrated ")
            print("   • Wear light cotton clothes")
            print("   • Use sunscreen ")
            print("   • Avoid going out in peak afternoon")
        elif temperature > 25:
            print("   • Perfect weather for outdoor activities! ")
            print("   • Stay hydrated")
            print("   • Enjoy the pleasant weather")
        elif temperature < 10:
            print("   • Wear warm clothes ")
            print("   • Drink hot beverages ")
            print("   • Use moisturizer for skin")
        elif "cloud" in description.lower():
            print("   • Great weather for walking! ")
            print("   • Carry a light jacket")
        else:
            print("   • Enjoy the pleasant weather! ")
    
    def save_to_file(self, city_name, weather_data):
        """
        Save weather data to a text file
        """
        try:
            filename = f"weather_{city_name.lower().replace(' ', '_')}.txt"
            with open(filename, 'w', encoding='utf-8') as file:
                file.write(f"WEATHER REPORT - {city_name.upper()}\n")
                file.write("=" * 40 + "\n")
                file.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                file.write(f"Description: {weather_data['weather'][0]['description'].title()}\n")
                file.write(f"Temperature: {weather_data['main']['temp']}°C\n")
                file.write(f"Feels like: {weather_data['main']['feels_like']}°C\n")
                file.write(f"Humidity: {weather_data['main']['humidity']}%\n")
                file.write(f"Pressure: {weather_data['main']['pressure']} hPa\n")
                file.write(f"Wind Speed: {weather_data['wind']['speed']} m/s\n")
                file.write(f"Sunrise: {datetime.fromtimestamp(weather_data['sys']['sunrise']).strftime('%H:%M:%S')}\n")
                file.write(f"Sunset: {datetime.fromtimestamp(weather_data['sys']['sunset']).strftime('%H:%M:%S')}\n")
            
            print(f" Weather data saved to '{filename}'")
            
        except Exception as e:
            print(f" Error saving file: {e}")
    
    def run(self):
        """
        Main function to run the weather application
        """
        print("  =================================")
        print("     WELCOME TO WEATHER APP")
        print("================================ ")
        print("Get real-time weather information for any city!")
        print(f"API Key Status: ACTIVE")
        
        while True:
            print("\n" + "-"*40)
            print("1. Check Weather")
            print("2. Multiple Cities")
            print("3. Exit")
            print("-"*40)
            
            choice = input("Choose option (1/2/3): ").strip()
            
            if choice == '1':
                city_name = input("Enter city name: ").strip()
                if city_name:
                    self.get_weather(city_name)
                else:
                    print("Please enter a valid city name!")
            
            elif choice == '2':
                cities = input("Enter city names (comma separated): ").strip()
                if cities:
                    city_list = [city.strip() for city in cities.split(',')]
                    for city in city_list:
                        if city:
                            self.get_weather(city)
                            print("\n" + "="*60 + "\n")
                else:
                    print("Please enter valid city names!")
            
            elif choice == '3':
                print("Thank you for using Weather App! Goodbye!")
                break
            
            else:
                print("Invalid choice! Please enter 1, 2, or 3.")

# Run the application
if __name__ == "__main__":
    app = WeatherApp()
    app.run()