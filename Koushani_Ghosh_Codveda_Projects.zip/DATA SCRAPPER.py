# 2 TASK PROJECT(CODVEDA TECHNOLOGIES) --DATA SCRAPER(WEB SCRAPER)


import requests
from bs4 import BeautifulSoup
import csv


def scrape_news_headlines():
    """
    Scrapes news headlines from BBC News website
    """
    url = "https://bbc.com/news"

    try:

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }

        print(" Connecting to website...")
    
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()

        print(" Website connected successfully!")


        soup = BeautifulSoup(response.content, 'html.parser')

     
        headlines = []

       
        selectors_to_try = [
            'h3',
            'h2',
            '.gs-c-promo-heading__title',
            'a[class*="headline"]',
            '[data-entityid*="container"] h3'
        ]

        for selector in selectors_to_try:
            found_headlines = soup.select(selector)
            if found_headlines:
                headlines.extend(found_headlines[:15])  # Get first 15 of each type
                print(f"Found {len(found_headlines)} elements with selector: {selector}")

        headline_list = []
        for headline in headlines[:20]:  # Limit to 20 headlines
            title = headline.get_text().strip()
            if title and len(title) > 5:  # Filter very short texts
                headline_list.append(title)

        headline_list = list(dict.fromkeys(headline_list))

      
        if headline_list:
            with open('news_headlines.csv', 'w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow(['Headline'])
                for headline in headline_list:
                    writer.writerow([headline])

            print(f" Successfully scraped {len(headline_list)} headlines!")
            print("Data saved to 'news_headlines.csv'")

           
            print("\n Scraped Headlines:")
            for i, headline in enumerate(headline_list, 1):
                print(f"{i}. {headline}")
        else:
            print("No headlines found. The website structure might have changed.")

    except requests.exceptions.RequestException as e:
        print(f"Network error: {e}")
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    scrape_news_headlines()